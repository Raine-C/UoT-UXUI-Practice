// Create a variable below

// Console.log() your variable here.
