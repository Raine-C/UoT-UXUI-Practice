// Create the addNumbers function here.

// Create the stringConcat function here.
