$("#toggle").on("click", function(){
  $("#dropDown").slideToggle();
});
